package main

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"math"
	"math/big"
	"time"
	"flag"
	"strconv"


	"github.com/lucas-clemente/quic-go"
)

//const addr = "localhost:4242"

const message = "SciStream"

// We start a server on the first stream the client opens,
// then connect with a client, send the message, and wait for its receipt.
func main() {
//go func() { log.Fatal(echoServer()) }()
	addr := flag.String("addr", "localhost:4242", "Proxy address and port")
	size := flag.Int("size", 1024, "Sample size in bytes")
	dataset := flag.Int("dataset", 10, "Dataset size in bytes")
	jitter := flag.Bool("jitter", false, "Reduce the generation rate to 1 KHz")

	flag.Parse()

	samples := 1024
	//2 to the power of 30 may loss a lot of packages - should sync with receiver largeNumber
	largeNumber := *dataset * int(math.Pow(2, 25)) / *size
	s1 := strconv.Itoa(largeNumber)
  fmt.Printf("%v\n", s1)

	if *jitter ==true {
	    samples = 100000
	} else {
	    samples = largeNumber
	}

	err := clientMain(*addr,samples)
	if err != nil {
		panic(err)
	}
}

func clientMain(addr string, samples int) error {
	tlsConf := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}
	conn, err := quic.DialAddr(addr, tlsConf, nil)
	if err != nil {
		return err
	}

	stream, err := conn.OpenStreamSync(context.Background())
	//stream, err := conn.OpenUniStreamSync(context.Background())
	if err != nil {
		return err
	}

	//sending random staff
	//delay 20 Millisecond, assume sending one sample each Millisecond
	samples = samples / 20
	for i:=0; i <= samples; i++ {
		message := message
		//message := strings.Repeat("a", 1024)
		//fmt.Printf(message)

		_, err = stream.Write([]byte(message))
		if err != nil {
			return err
		}
		//This line change the sending frequence.
		time.Sleep(20 * time.Millisecond)
	}
	time.Sleep(10000 * time.Millisecond)
	stopMessage := "STOP"
	fmt.Printf("Sending STOP!!!")
	_, err = stream.Write([]byte(stopMessage))
	if err != nil {
		return err
	}

	// buf := make([]byte, 100)
	// //received_stream, err := io.ReadFull(stream, buf)
	// for {
	// 	n, err := stream.Read(buf)
	// 	fmt.Printf("n = %v err = %v b = %v\n", n, err, buf)
	// 	fmt.Printf("b[:n] = %q\n", buf[:n])
	// 	if err != nil{
	// 		fmt.Printf("err = %v\n",  err)
	// 		break
	// 	}
	// }
	//
	// //fmt.Printf("Received stream: Got '%s'\n", received_stream)
	// // if err != nil {
	// // 	return err
	// // }
	// fmt.Printf("Client: Got '%s'\n", buf)
	return nil
}

// A wrapper for io.Writer that also logs the message.
type loggingWriter struct{ io.Writer }

func (w loggingWriter) Write(b []byte) (int, error) {
	fmt.Printf("Server: Got '%s'\n", string(b))
	return w.Writer.Write(b)
}

// Setup a bare-bones TLS config for the server
func generateTLSConfig() *tls.Config {
	key, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		panic(err)
	}
	template := x509.Certificate{SerialNumber: big.NewInt(1)}
	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
	if err != nil {
		panic(err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(key)})
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	tlsCert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		panic(err)
	}
	return &tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		NextProtos:   []string{"quic-echo-example"},
	}
}
