package main

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
  "flag"
	"strings"
	"strconv"
	"time"
	"math"

	"github.com/montanaflynn/stats"
	"github.com/lucas-clemente/quic-go"
)

//const addr = "localhost:5252"
var count int = 0
//var timeNow int64 = time.Now().UnixMilli()
var inter_msg_space []float64
var timeInit int64

// We start a server echoing data on the first stream the client opens,
// then connect with a client, send the message, and wait for its receipt.
func main() {
  addr := flag.String("addr", "localhost:5252", "Proxy address and port")

	flag.Parse()

  err := echoServer(*addr)
	if err != nil {
		panic(err)
	}

}

// Start a server that echos all data on the first stream opened by the client
func echoServer(addr string) error {
  listener, err := quic.ListenAddr(addr, generateTLSConfig(), nil)
	if err != nil {
		return err
	}
	conn, err := listener.Accept(context.Background())
	if err != nil {
		return err
	}
	stream, err := conn.AcceptStream(context.Background())
	if err != nil {
		panic(err)
	}
	timeInit = time.Now().Unix()
	// Echo through the loggingWriter
	_, err = io.Copy(loggingWriter{stream}, stream)
	return err
}

// A wrapper for io.Writer that also logs the message.
type loggingWriter struct{ io.Writer }

func (w loggingWriter) Write(b []byte) (int, error) {
	//fmt.Printf("Got '%s'\n", string(b))
	timeNow := time.Now().Unix() //it may take 20 Milliseconds to run this...

	//packet send every 20 Milliseconds, assume received one packet per Millisecond
	count = count + 20
	t_last_msg := timeNow
	if strings.Contains(string(b), "ST") {
		t := t_last_msg - timeInit
		//fmt.Printf("t is %s\n", strconv.FormatInt(t, 10))
		fmt.Printf("Received %s\n", strconv.Itoa(count))
		//should sync with sender largeNumber
		largeNumber := math.Pow(2, 25)
		//minus 1 because the last stop message delay for 1 seconds
		throughput := (8 * 1024 * float64(count)) * 10/ (largeNumber * float64(t-1) )
		//fmt.Printf("throughput is %f\n", throughput)
		samples := 10 * largeNumber / 1024
		efficiency := float64(count) / samples
		avg_ims, _ := stats.Mean(inter_msg_space)
		jitter, _ := stats.StandardDeviation(inter_msg_space)
		fmt.Printf("Elapsed: %s secs. | Throughput: %f Gbps | Jitter: %f | Inter-message Space: %f | Efficiency: %f \n" , strconv.FormatInt(t, 10), throughput, jitter, avg_ims, efficiency)
	} else{
		inter_msg_space = append(inter_msg_space, float64(timeNow - t_last_msg))
		t_last_msg = timeNow
		fmt.Printf("t_last_msg is %s\n", strconv.FormatInt(t_last_msg, 10))
	}

	return w.Writer.Write(b)
}

// Setup a bare-bones TLS config for the server
func generateTLSConfig() *tls.Config {
	key, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		panic(err)
	}
	template := x509.Certificate{SerialNumber: big.NewInt(1)}
	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
	if err != nil {
		panic(err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(key)})
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	tlsCert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		panic(err)
	}
	return &tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		NextProtos:   []string{"quic-echo-example"},
	}
}
