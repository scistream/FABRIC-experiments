package main

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"

	"github.com/lucas-clemente/quic-go"
)

const addr = "localhost:4243"
const addr2 = "localhost:5252"


// We start a server echoing data on the first stream the client opens,
// then connect with a client, send the message, and wait for its receipt.
func main() {

	err := echoServer()
	if err != nil {
		panic(err)
	}


}


// Start a server that echos all data on the first stream opened by the client
func echoServer() error {
	listener, err := quic.ListenAddr(addr, generateTLSConfig(), nil)
	if err != nil {
		return err
	}
	fmt.Printf("listener:  '%s'\n\n", listener)
	conn, err := listener.Accept(context.Background())
	if err != nil {
		return err
	}
	fmt.Printf("conn:  '%s'\n\n", conn)
	stream, err := conn.AcceptStream(context.Background())
	if err != nil {
		panic(err)
	}
	fmt.Printf("Stream:  '%s'\n\n", stream)

	//open a new proxy client-likewise connection
	tlsConf := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}
	conn2, err := quic.DialAddr(addr2, tlsConf, nil)
	if err != nil {
		return err
	}

	stream2, err := conn2.OpenStreamSync(context.Background())
	if err != nil {
		return err
	}

	buf := make([]byte, 100)
	for {
		n, err := stream.Read(buf)
		fmt.Printf("n = %v err = %v b = %v\n", n, err, buf)
		fmt.Printf("b[:n] = %q\n", buf[:n])
		fmt.Printf("Proxy: Sending '%s'\n", buf)
		_, err = stream2.Write([]byte(buf))

		if err != nil{
			fmt.Printf("err = %v\n",  err)
			break
		}
	}

	//received_stream, err := io.ReadFull(stream, buf)

	// Echo through the loggingWriter
	byte, err := io.Copy(io.Writer(stream), stream)
	fmt.Printf("after copy After:  '%s'\n", byte)
	return err
}

// Setup a bare-bones TLS config for the server
func generateTLSConfig() *tls.Config {
	key, err := rsa.GenerateKey(rand.Reader, 1024)
	if err != nil {
		panic(err)
	}
	template := x509.Certificate{SerialNumber: big.NewInt(1)}
	certDER, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
	if err != nil {
		panic(err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(key)})
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: certDER})

	tlsCert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		panic(err)
	}
	return &tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		NextProtos:   []string{"quic-echo-example"},
	}
}
