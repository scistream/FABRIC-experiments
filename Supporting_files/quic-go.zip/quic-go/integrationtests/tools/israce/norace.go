//go:build !race
// +build !race

package israce

// Enabled reports if the race detector is enabled.
const Enabled = false
